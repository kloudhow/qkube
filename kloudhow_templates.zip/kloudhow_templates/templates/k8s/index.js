const path = require('path');
const readline = require('readline');
const fs = require('fs');

module.exports = {
  description: 'New Deployment File',
  prompts: [
    {
      type: 'input',
      name: 'name',
      message: 'input deployment name'
    }
  ],
  actions: function(data) {
    const pathToContainer = path.join(process.cwd(), 'k8s');
    const pathToEnvFile = path.join(process.cwd(), '.env');
    console.log('pathToEnvFile',pathToEnvFile)
    global.env = {}
    //  Get ENV to global.env[]
    if(fs.existsSync(pathToEnvFile)) {
      console.log(pathToEnvFile)

      let envData = fs.readFileSync(pathToEnvFile, 'utf8')
      let lines = envData.split(/\r?\n/)
      // Skip # comment & empty
      lines = lines.filter((line)=> !line.includes('#')).filter(Boolean)

      for (let i = 0 ; i<lines.length; i++){
        console.log(lines[i])
        var [key, value] = lines[i].split('=');
        console.log({value, key})
        global.env[key] = value

      }

      // const readInterface = readline.createInterface({
      //   input: fs.createReadStream(pathToEnvFile)
      // });
      // readInterface.on('line', function (line) {
      //   var [newEnv, env] = line.split('=');
      //   global.env[newEnv] = '1'
      //   console.log('newEnv', newEnv)
      // });
    // }else{
      // Get ENV variables using ENVVAR_ prefix
      Object.keys(process.env)
          .filter((env) => {
            if (env.includes("ENVVAR_")) return env
          })
          .forEach((env) => {
            const reg = new RegExp("^" + "ENVVAR_");
            let newEnv = env.replace(reg, "");
            if (newEnv) {
              global.env[newEnv] = process.env[env]
            }
          })
    }

    console.log('global.env', global.env)

    if(Object.keys(global.env).length > 0){
      data.env = global.env
    }

    // check run multiple command
    let ENV_COMMAND = process.env.COMMAND || ''

    let ENV_COMMAND_ARRAY = ENV_COMMAND.split(new RegExp('[,|;]', 'g'))
    ENV_COMMAND_ARRAY = ENV_COMMAND_ARRAY.filter(Boolean)

    // default and
    // delimiter by ,;|
    data.COMMAND = ENV_COMMAND_ARRAY // should keep default
    // @TODO: update config
    data.GCP_PROJECT = process.env.GCP_PROJECT

    data.PVC_ENABLE = process.env.PVC_ENABLE
    data.PVC_MOUNTPATH = process.env.PVC_MOUNTPATH
    if(data.PVC_MOUNTPATH && data.PVC_ENABLE ) {
      data.PVC = 1
    }
    data.node_selector = process.env.node_selector
    data.SERVICE_PORT = process.env.SERVICE_PORT || 1337
    // overwrite target port
    data.TARGET_PORT = process.env.TARGET_PORT || data.SERVICE_PORT
    data.REPLICAS = process.env.REPLICAS || 1
    data.MIN_REPLICAS = process.env.MIN_REPLICAS || 1
    data.MAX_REPLICAS = process.env.MAX_REPLICAS || 10

    const actions = [
      {
        type: 'add',
        path: path.join(pathToContainer, 'uat-{{dashCase name}}.yml'),
        templateFile: path.join(__dirname, 'deployment.yml.hbs'),
        force: true,
        data: {
          ...data,
          uat: true,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'hotfix-{{dashCase name}}.yml'),
        templateFile: path.join(__dirname, 'deployment.yml.hbs'),
        force: true,
        data: {
          ...data,
          hotfix: true,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'prod-{{dashCase name}}.yml'),
        templateFile: path.join(__dirname, 'deployment.yml.hbs'),
        force: true,
        data: {
          ...data,
          prod: true,
        },
        abortOnFail: true
      }
    ];

    return actions;
  }
};
