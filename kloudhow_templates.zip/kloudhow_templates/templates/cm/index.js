const path = require('path');
const readline = require('readline');
const fs = require('fs');

module.exports = {
  description: 'New configmap File',
  prompts: [
    {
      type: 'input',
      name: 'name',
      message: 'input configmap name'
    }
  ],
  actions: function(data) {
    const pathToContainer = path.join(process.cwd(), 'cm');
    const pathToEnvFile = path.join(process.cwd(), '.env');
    console.log('pathToEnvFile',pathToEnvFile)
    global.env = {}

    if(fs.existsSync(pathToEnvFile)) {
      console.log(pathToEnvFile)

      let envData = fs.readFileSync(pathToEnvFile, 'utf8')
      let lines = envData.split(/\r?\n/)
      // Skip # comment & empty
      lines = lines.filter((line)=> !line.includes('#')).filter(Boolean)

      for (let i = 0; i < lines.length; i++) {
        console.log(lines[i])
        var [key, value] = lines[i].split('=');
        console.log({
          value,
          key
        })
        global.env[key] = value

      }
    }

    Object.keys(process.env)
        .filter((env) => {
          if (env.includes("ENVVAR_")) return env
        })
        .forEach((env) => {
          const reg = new RegExp("^" + "ENVVAR_");
          let newEnv = env.replace(reg, "");
          if (newEnv) {
            global.env[newEnv] = process.env[env]
          }
        })
    // @TODO: update config
    data.GCP_PROJECT = process.env.GCP_PROJECT
    if(Object.keys(global.env).length > 0){
      data.env = global.env
    }
    const actions = [
      {
        type: 'add',
        path: path.join(pathToContainer, 'uat-{{dashCase name}}-configmap.yml'),
        templateFile: path.join(__dirname, 'configmap.yml.hbs'),
        force: true,
        data: {
          ...data,
          uat: true,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'hotfix-{{dashCase name}}-configmap.yml'),
        templateFile: path.join(__dirname, 'configmap.yml.hbs'),
        force: true,
        data: {
          ...data,
          hotfix: true,
        },
        abortOnFail: true
      },
      {
        type: 'add',
        path: path.join(pathToContainer, 'prod-{{dashCase name}}-configmap.yml'),
        templateFile: path.join(__dirname, 'configmap.yml.hbs'),
        force: true,
        data: {
          ...data,
          prod: true,
        },
        abortOnFail: true
      }
    ];

    return actions;
  }
};
